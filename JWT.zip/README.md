# jwt-php-project
This is a simple JWT project using PHP.


### Author
[Yusuf Shakeel](https://github.com/yusufshakeel)

### License

MIT License Copyright (c) 2018 Yusuf Shakeel

### Project Tutorial

[Click here](https://www.dyclassroom.com/json-web-tokens/jwt-project-firebase-php-jwt-introduction) for the project tutorial.